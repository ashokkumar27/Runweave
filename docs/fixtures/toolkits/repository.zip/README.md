# Service contract
TIMEOUT_SECONDS must be 60.
